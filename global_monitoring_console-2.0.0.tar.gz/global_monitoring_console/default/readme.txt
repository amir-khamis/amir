This is where you put all your configs for this app. Splunk Web will write out configs here, too.
add your own LAT/LON like this example at the bottom of the search to default to your HQ Location:  | fillnull value="37.782768" work_lat  | fillnull value="-122.391289" work_long
