// #                                                                                                        
// #   Licensed under the Apache License, Version 2.0 (the "License");                                      
// #   you may not use this file except in compliance with the License.                                     
// #   You may obtain a copy of the License at                                                              
// #                                                                                                        
// #       http://www.apache.org/licenses/LICENSE-2.0                                                       
// #                                                                                                        
// #   Unless required by applicable law or agreed to in writing, software                                  
// #   distributed under the License is distributed on an "AS IS" BASIS,                                    
// #   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.                             
// #   See the License for the specific language governing permissions and                                  
// #   limitations under the License.

require([
    'splunkjs/ready!',
    'splunkjs/mvc/simplexml/ready!',
    'underscore',
    'jquery',
    'splunkjs/splunk',
    '../app/TA_global_monitoring_console/components/js_sdk_extensions/macros',
    '../app/TA_global_monitoring_console/components/js_sdk_extensions/saved_searches'
], function(
    mvc,
    ignored,
    _,
    $,
    splunk_js_sdk,
    sdkx_macros,
    sdkx_saved_searches
) {
    var Macro = sdkx_macros.Macro;
    var Macros = sdkx_macros.Macros;
    var SavedSearch = sdkx_saved_searches.SavedSearch;
    var SavedSearches = sdkx_saved_searches.SavedSearches;
    
    var service = mvc.createService();
    var cleaned_data = {};
    
    // -------------------------------------------------------------------------
    // Prerequisite Checks
    
    // Error if running on unrecognized unix
    // 
    service.get('/services/SetupService', cleaned_data, function(err, response){
        if(err){
            console.error("Problem fetching data", err)
        }
        else if(response.status === 200){
	    var isRecognizedUnix = JSON.parse(response.data);
            if (!isRecognizedUnix) {
                $('#not-unix-error').show();
                $('#save-btn').addClass('disabled');
            }
        }
        else {
            console.error('Problem checking whether splunkweb is running on Unix.');
        }
    });
    
    // -------------------------------------------------------------------------
    // Populate Tables
    
    var INPUT_ROW_TEMPLATE = _.template(
        '<tr class="input" data-fullname="<%- fullname %>">\n' +
        '    <td><%- name %></td>\n' +
        '    <td><input class="enable-btn"  type="radio" name="<%- name %>" <% if (enabled)  { %>checked="checked"<% } %> /></td>\n' +
        '    <td><input class="disable-btn" type="radio" name="<%- name %>" <% if (!enabled) { %>checked="checked"<% } %> /></td><td>"<%- description %>"</td>\n' +
        '</tr>\n');
    
    // I. Enable IOC Jobs that generates KV Stores from various Splunk REST Endpoints:
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re_1 = new RegExp("splunk_rest_.*_kv_store_lookup_gen");
            var re_2 = new RegExp("splunk_rest_itsi_.*_kv_store_lookup_gen");
            var re_3 = new RegExp("splunk_index_itsi_summary_sh_kv_store_lookup_gen");
            var re_4 = new RegExp("splunk_audit_user_login_idx_summary_tracker");
            var re_5 = new RegExp("splunk_internal_scheduler_jobs_idx_summary_tracker");
            var re_6 = new RegExp("splunk_internal_web_access_idx_summary_tracker");
            var re_7 = new RegExp("splunk_rest_messages_sh_summary_tracker");
            var re_8 = new RegExp("splunk_rest_search_jobs_sh_summary_tracker");
            var re_9 = new RegExp("splunk_rest_data_index_volumes_idx_kv_store_lookup_gen");
            if ( ( re_1.test(input.name) || re_2.test(input.name) || re_3.test(input.name) || re_4.test(input.name) || re_5.test(input.name) || re_6.test(input.name) || re_7.test(input.name) || re_8.test(input.name) ) && !re_9.test(input.name) ) {      
             return input
            }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table1').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Define the GMC Macros Table
    var INPUT_ROW_TEMPLATE_MACROS = _.template(
        '<tr class="input" data-fullname="<%- fullname %>">\n' +
        '    <td><%- name %></td>\n' +
        '    <td><input class="definition-btn" type="text" style="width: 500px;" name="<%- name %>" value="<%- definition %>"></input></td><td>"<%- description %>"</td>'+
        '</tr>\n');
    
    // Populate Enable GMC Macros Table1
    var macros = {};
    new Macros(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re_1 = new RegExp("setup_.*_search_head_rest");
            var re_2 = new RegExp("setup_summary_index");
            var re_3 = new RegExp("setup_group_search_head_rest");
            if ( ( re_1.test(input.name) || re_2.test(input.name) )  && !re_3.test(input.name) ) {
              return input
            }
        });
        _.each(inputsList, function(input) {
            $('#macros-table1').append($(INPUT_ROW_TEMPLATE_MACROS({
                fullname: input.name,
                name: input.name,
                definition: input.properties().definition,
                description: input.properties().description
            })));
            macros[input.name] = input;
        });
    });

    // -------------------------------------------------------------------------
    // Buttons
    
    // Enable All button
    $('.enable-all-btn').click(function(e) {
        e.preventDefault();
        var table = $(e.target).closest('.input-table');
        $('.input .enable-btn', table).prop('checked', true);
    });
    
    // Disable All button
    $('.disable-all-btn').click(function(e) {
		e.preventDefault();
        var table = $(e.target).closest('.input-table');
        $('.input .disable-btn', table).prop('checked', true);
    });
    
    // Save button
    $('#save-btn').click(function(e) {
		e.preventDefault();
        if ($('#save-btn').hasClass('disabled')) {
            return;
        }
        
        var savesPending = 0;
        var saveErrors = [];
        
        // Save Enable Schedule for GMC Jobs that generates KV Stores from various Splunk REST Endpoints
        _.each($('#saved-search-table1 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });
        
         // Save Macros1
        _.each($('#macros-table1 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            //var enabled = $('.enable-btn', inputElem).prop('checked');
            var definition = $('.definition-btn', inputElem).prop('value');
           // console.log(definition);
            var input = macros[fullname];
            
            savesPending++;
            input.update({
                 'definition': definition
             }, saveDone);
        });

        //Set is_configured=true in app.conf
        service.post('/services/SetupService', cleaned_data, function(err, response){
            if(err){
                console.log("Error saving configuration in app.conf")
            }
        });

        // After saves are complete...
        function saveDone(err, entity) {
            if (err) {
                saveErrors.push(err);
            }
            
            savesPending--;
            if (savesPending > 0) {
                return;
            }
            
            if (saveErrors.length === 0) {
                // Save successful. Provide feedback in form of page reload.
                window.location.reload();
            } else {
                // Save failed.
                $('#generic-save-error').show();
                
                // (Allow Support to debug if necessary.)
                console.log('Errors while saving:');
                console.log(saveErrors);
            }
        }
    });
});
