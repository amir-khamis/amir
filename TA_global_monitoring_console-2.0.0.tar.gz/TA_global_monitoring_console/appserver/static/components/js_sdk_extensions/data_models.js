// #                                                                                                        
// #   Licensed under the Apache License, Version 2.0 (the "License");                                      
// #   you may not use this file except in compliance with the License.                                     
// #   You may obtain a copy of the License at                                                              
// #                                                                                                        
// #       http://www.apache.org/licenses/LICENSE-2.0                                                       
// #                                                                                                        
// #   Unless required by applicable law or agreed to in writing, software                                  
// #   distributed under the License is distributed on an "AS IS" BASIS,                                    
// #   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.                             
// #   See the License for the specific language governing permissions and                                  
// #   limitations under the License.

define([
    'splunkjs/ready!',   // for splunkjs global
    './common'
], function(
    mvc,
    sdkx_common)
{
    var root = {
        Entity: splunkjs.Service.Entity,
        Collection: splunkjs.Service.Collection
    };
    
    var utils_namespaceFromProperties = sdkx_common.utils_namespaceFromProperties;
    
    // -------------------------------------------------------------------------
    // JS SDK Extension: Data_models
    
    var Paths = {   
        dataModels: 'data/models'
    };
    
    root.DataModel = root.Entity.extend({
        path: function() {
            return Paths.dataModels + "/" + encodeURIComponent(this.name);
        },
        
        init: function(service, name, namespace) {
            this.name = name;
            this._super(service, this.path(), namespace);
        },
        
        _load: function(properties) {
            this._super(properties);
            if (this.state().id) {
                this.qualifiedPath = this.state().id.match(/\/servicesNS\/.*$/)[0];
            }
        }
    });
    
    root.DataModels = root.Collection.extend({
        path: function() {
            return Paths.dataModels;
        },
        
        instantiateEntity: function(props) {
            var entityNamespace = utils_namespaceFromProperties(props);
            return new root.DataModel(this.service, props.name, entityNamespace);
        },
        
        init: function(service, namespace) {
            this._super(service, this.path(), namespace);
        }
    });
    
    return root;
});