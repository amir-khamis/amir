// #                                                                                                        
// #   Licensed under the Apache License, Version 2.0 (the "License");                                      
// #   you may not use this file except in compliance with the License.                                     
// #   You may obtain a copy of the License at                                                              
// #                                                                                                        
// #       http://www.apache.org/licenses/LICENSE-2.0                                                       
// #                                                                                                        
// #   Unless required by applicable law or agreed to in writing, software                                  
// #   distributed under the License is distributed on an "AS IS" BASIS,                                    
// #   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.                             
// #   See the License for the specific language governing permissions and                                  
// #   limitations under the License.

require([
    'splunkjs/ready!',
    'splunkjs/mvc/simplexml/ready!',
    'underscore',
    'jquery',
    'splunkjs/splunk',
    '../app/TA_global_monitoring_console/components/js_sdk_extensions/macros',
    // '../app/TA_global_monitoring_console/components/js_sdk_extensions/data_models',
    '../app/TA_global_monitoring_console/components/js_sdk_extensions/saved_searches'
], function(
    mvc,
    ignored,
    _,
    $,
    splunk_js_sdk,
    sdkx_macros,
    // sdkx_data_models,
    sdkx_saved_searches
) {
    var Macro = sdkx_macros.Macro;
    var Macros = sdkx_macros.Macros;
    // var DataModel = sdkx_macros.DataModel;
    // var DataModels = sdkx_macros.DataModels;
    var SavedSearch = sdkx_saved_searches.SavedSearch;
    var SavedSearches = sdkx_saved_searches.SavedSearches;
    
    var service = mvc.createService();
    var cleaned_data = {};
    
    // -------------------------------------------------------------------------
    // Prerequisite Checks
    
    // Error if running on unrecognized unix
    // 
    service.get('/services/SetupService', cleaned_data, function(err, response){
        if(err){
            console.error("Problem fetching data", err)
        }
        else if(response.status === 200){
	    var isRecognizedUnix = JSON.parse(response.data);
            if (!isRecognizedUnix) {
                $('#not-unix-error').show();
                $('#save-btn').addClass('disabled');
            }
        }
        else {
            console.error('Problem checking whether splunkweb is running on Unix.');
        }
    });
    
    // -------------------------------------------------------------------------
    // Populate Tables
    
    var INPUT_ROW_TEMPLATE = _.template(
        '<tr class="input" data-fullname="<%- fullname %>">\n' +
        '    <td><%- name %></td>\n' +
        '    <td><input class="enable-btn"  type="radio" name="<%- name %>" <% if (enabled)  { %>checked="checked"<% } %> /></td>\n' +
        '    <td><input class="disable-btn" type="radio" name="<%- name %>" <% if (!enabled) { %>checked="checked"<% } %> /></td><td>"<%- description %>"</td>\n' +
        '</tr>\n');
    
    // Populate Enable Schedule for GMC Jobs that generates KV Stores from various Splunk REST Endpoints table
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^splunk_rest_.*_kv_store_lookup_gen");
            var re_2 = new RegExp("splunk_cloud_stack_csv_shcluster_config_shc_kv_store_lookup_gen");
            if (re.test(input.name) || re_2.test(input.name) ) {
                 return input
                }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table1').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Populate Enable Schedule for GMC Jobs that generates Summary Indexing Data from various Splunk REST Endpoints table
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^splunk_rest_.*_summary_data_gen");
                if (re.test(input.name))  {
                 return input
                }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table2').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Populate Enable Schedule for GMC Jobs that Generates KV Stores from the GMC Summary Index table
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^splunk_summary_.*_kv_store_lookup_gen");
            var re_2 = new RegExp("splunk_index_itsi_summary_sh_kv_store_lookup_gen");
                if (re.test(input.name) || re_2.test(input.name) ) {
                 return input
                }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table3').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Populate Enable Enable Schedule for GMC Tracker Jobs that keeps KV Stores up-to-date table
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^splunk_.*_kv_store_lookup_tracker");
                if (re.test(input.name))  {
                 return input
                }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table4').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Populate Enable Enable Schedule for GMC Tracker Jobs that keeps the GMC Summary Index up-to-date table
    var savedSearches = {};
    new SavedSearches(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^splunk_.*_summary_tracker");
                if (re.test(input.name))  {
                 return input
                }
        });
        
        _.each(inputsList, function(input) {
            $('#saved-search-table5').append($(INPUT_ROW_TEMPLATE({
                fullname: input.name,
                name: input.name,
                enabled: input.properties().is_scheduled,
                description: input.properties().description
            })));
            savedSearches[input.name] = input;
        });
    });

    // Define the GMC Macros Table
    var INPUT_ROW_TEMPLATE_MACROS = _.template(
        '<tr class="input" data-fullname="<%- fullname %>">\n' +
        '    <td><%- name %></td>\n' +
        '    <td><input class="definition-btn" type="text" style="width: 500px;" name="<%- name %>" value="<%- definition %>"></input></td><td>"<%- description %>"</td>'+
        '</tr>\n');
    
    // Populate Enable GMC Macros Table1
    var macros = {};
    new Macros(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^gmc_setup_.*_rest$");
            if (re.test(input.name)) {
              return input
            }
        });
        _.each(inputsList, function(input) {
            $('#macros-table1').append($(INPUT_ROW_TEMPLATE_MACROS({
                fullname: input.name,
                name: input.name,
                definition: input.properties().definition,
                description: input.properties().description
            })));
            macros[input.name] = input;
        });
    });
    
    // Populate Enable GMC Macros Table2
    var macros = {};
    new Macros(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("^gmc_setup_.*_search$");
            // var re_two = new RegExp("set_geo_defaults");
            // if (re.test(input.name) || re_two.test(input.name)) {
            if (re.test(input.name)) {
              return input
            }
        });
        _.each(inputsList, function(input) {
            $('#macros-table2').append($(INPUT_ROW_TEMPLATE_MACROS({
                fullname: input.name,
                name: input.name,
                definition: input.properties().definition,
                description: input.properties().description
            })));
            macros[input.name] = input;
        });
    });

    // Populate Enable GMC Macros Table3
    var macros = {};
    new Macros(
        service,
        { owner: '-', app: 'TA_global_monitoring_console', sharing: 'app' }
    ).fetch(function(err, inputs) {
        var inputsList = _.filter(inputs.list(), function(input) {
            var re = new RegExp("gmc_setup_.*_geo");
            var re_2 = new RegExp("gmc_setup_emp_.*");
            var re_3 = new RegExp("gmc_setup_get_dmc_assets_info");
            var re_4 = new RegExp("gmc_setup_summary_index");
            if (re.test(input.name) || re_2.test(input.name) || re_3.test(input.name) || re_4.test(input.name) ) {
              return input
            }
        });
        _.each(inputsList, function(input) {
            $('#macros-table3').append($(INPUT_ROW_TEMPLATE_MACROS({
                fullname: input.name,
                name: input.name,
                definition: input.properties().definition,
                description: input.properties().description
            })));
            macros[input.name] = input;
        });
    });

    // Define the GMC Data Model
    // var INPUT_ROW_TEMPLATE_DATA_MODELS  = _.template(
    //         '<tr class="input" data-fullname="<%- fullname %>">\n' +
    //     '    <td><%- name %></td>\n' +
    //     '    <td><input class="acceleration-btn" type="radio" style="width: 500px;" name="<%- name %>" value="<%- acceleration %>"></input></td><td>"<%- description %>"</td>'+
    //     '</tr>\n');

    // Populate Enable GMC Data Model Table1
    // var dataModels = {};
    // new DataModels(
    //     service,
    //     { owner: '-', app: 'global_monitoring_console', sharing: 'global' }
    // ).fetch(function(err, inputs) {
    //     var inputsList = _.filter(inputs.list(), function(input) {
    //         var re = new RegExp("GMC");
    //             if (re.test(input.name))  {
    //              return input
    //             }
    //     });
        
    //     _.each(inputsList, function(input) {
    //         $('#data-models-table1').append($(INPUT_ROW_TEMPLATE_DATA_MODELS({
    //             fullname: input.name,
    //             name: input.name,
    //             enabled: input.properties().acceleration,
    //             description: input.properties().description
    //         })));
    //         dataModels[input.name] = input;
    //     });
    // });
    
    // -------------------------------------------------------------------------
    // Buttons
    
    // Enable All button
    $('.enable-all-btn').click(function(e) {
        e.preventDefault();
        var table = $(e.target).closest('.input-table');
        $('.input .enable-btn', table).prop('checked', true);
    });
    
    // Disable All button
    $('.disable-all-btn').click(function(e) {
		e.preventDefault();
        var table = $(e.target).closest('.input-table');
        $('.input .disable-btn', table).prop('checked', true);
    });
    
    // Save button
    $('#save-btn').click(function(e) {
		e.preventDefault();
        if ($('#save-btn').hasClass('disabled')) {
            return;
        }
        
        var savesPending = 0;
        var saveErrors = [];
        
        // Save Enable Schedule for GMC Jobs that generates KV Stores from various Splunk REST Endpoints
        _.each($('#saved-search-table1 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });

        // Save Enable Schedule for GMC Jobs that generates Summary Indexing Data from various Splunk REST Endpoints
        _.each($('#saved-search-table2 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });

        // Save Enable Schedule for GMC Jobs that Generates KV Stores from the GMC Summary Index
        _.each($('#saved-search-table3 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });

        // Save Enable Schedule for GMC Tracker Jobs that keeps KV Stores up-to-date
        _.each($('#saved-search-table4 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });

        // Save Enable Schedule for GMC Tracker Jobs that keeps the GMC Summary Index up-to-date
        _.each($('#saved-search-table5 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            var enabled = $('.enable-btn', inputElem).prop('checked');
            
            var input = savedSearches[fullname];
            
            savesPending++;
            input.update({
                'is_scheduled': enabled
            }, saveDone);
        });
        
         // Save Macros1
        _.each($('#macros-table1 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            //var enabled = $('.enable-btn', inputElem).prop('checked');
            var definition = $('.definition-btn', inputElem).prop('value');
           // console.log(definition);
            var input = macros[fullname];
            
            savesPending++;
            input.update({
                 'definition': definition
             }, saveDone);
        });

         // Save Macros2
        _.each($('#macros-table2 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            //var enabled = $('.enable-btn', inputElem).prop('checked');
            var definition = $('.definition-btn', inputElem).prop('value');
           // console.log(definition);
            var input = macros[fullname];
            
            savesPending++;
            input.update({
                 'definition': definition
             }, saveDone);
        });

        // Save Macros3
        _.each($('#macros-table3 .input'), function(inputElem) {
            var fullname = $(inputElem).data('fullname');
            //var enabled = $('.enable-btn', inputElem).prop('checked');
            var definition = $('.definition-btn', inputElem).prop('value');
           // console.log(definition);
            var input = macros[fullname];
            
            savesPending++;
            input.update({
                 'definition': definition
             }, saveDone);
        });
        
        // Save Data Models 1
        // _.each($('#data-models-table1 .input'), function(inputElem) {
        //     var fullname = $(inputElem).data('fullname');
        //     //var enabled = $('.enable-btn', inputElem).prop('checked');
        //     var acceleration = $('.acceleration-btn', inputElem).prop('value');
        //    // console.log(acceleration);
        //     var input = macros[fullname];
            
        //     savesPending++;
        //     input.update({
        //          'acceleration': acceleration
        //      }, saveDone);
        // });

        //Set is_configured=true in app.conf
        service.post('/services/SetupService', cleaned_data, function(err, response){
            if(err){
                console.log("Error saving configuration in app.conf")
            }
        });

        // After saves are complete...
        function saveDone(err, entity) {
            if (err) {
                saveErrors.push(err);
            }
            
            savesPending--;
            if (savesPending > 0) {
                return;
            }
            
            if (saveErrors.length === 0) {
                // Save successful. Provide feedback in form of page reload.
                window.location.reload();
            } else {
                // Save failed.
                $('#generic-save-error').show();
                
                // (Allow Support to debug if necessary.)
                console.log('Errors while saving:');
                console.log(saveErrors);
            }
        }
    });
});
