Global Monitoring Console App for Splunk (GMC)
Copyright (C) 2005-2020 Splunk Inc. All Rights Reserved.

For documentation, see: https://github.com/amir-khamis/gmc
